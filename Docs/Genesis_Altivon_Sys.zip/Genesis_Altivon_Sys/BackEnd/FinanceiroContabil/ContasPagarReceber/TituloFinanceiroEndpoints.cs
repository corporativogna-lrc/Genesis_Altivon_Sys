namespace GenesisAltivonSys.BackEnd.FinanceiroContabil.ContasPagarReceber;

/// <summary>Arquivo da estrutura Genesis_Altivon_Sys. Implementação ainda não escrita: este arquivo não expõe rota, não persiste dados e não retorna resultado.</summary>
public static class TituloFinanceiroEndpoints
{
}
