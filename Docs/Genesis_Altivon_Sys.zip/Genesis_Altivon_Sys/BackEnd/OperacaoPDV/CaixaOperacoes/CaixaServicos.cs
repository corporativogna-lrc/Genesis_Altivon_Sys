namespace GenesisAltivonSys.BackEnd.OperacaoPDV.CaixaOperacoes;

/// <summary>Arquivo da estrutura Genesis_Altivon_Sys. Implementação ainda não escrita: este arquivo não expõe rota, não persiste dados e não retorna resultado.</summary>
public static class CaixaServicos
{
}
